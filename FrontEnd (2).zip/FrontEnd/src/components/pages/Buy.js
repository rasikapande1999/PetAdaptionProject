import React from "react";
import "../../App.css";

export default function Buy() {
  return <h1 className="buy">BUY</h1>;
}
