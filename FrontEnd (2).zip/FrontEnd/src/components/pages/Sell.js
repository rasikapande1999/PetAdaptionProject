import React from "react";

export default function Sell() {
  return <h1 className="sell">Sell</h1>;
}
