import React from "react";

export default function Petveterinary() {
  return <h1 className="Petveterinary">pet Vatr</h1>;
}
