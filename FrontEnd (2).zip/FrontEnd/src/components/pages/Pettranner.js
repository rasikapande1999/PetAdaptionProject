import React from "react";

export default function Pettranner() {
  return <h1 className="pettranner">Pet Trainer</h1>;
}
