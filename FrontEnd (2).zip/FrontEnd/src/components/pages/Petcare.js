import React from "react";
import "../../App.css";

export default function Petcare() {
  return <h1 className="petcare">Pet Care</h1>;
}
